package bitc.fullstack503.java503_team3;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Java503Team3Application {
    public static void main(String[] args) {
        SpringApplication.run(Java503Team3Application.class, args);
    }
}
