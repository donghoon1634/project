package bitc.fullstack503.java503_team3.dto;
import lombok.Data;

@Data
public class CategoryDTO {
  private int categoryNum; //물품 카테고리 넘버
  private String categoryName; // 카테고리 명칭
}
