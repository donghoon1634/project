package bitc.fullstack503.java503_team3.dto;
import lombok.Data;
@Data
public class LoadAddrDTO
{
  private String loadAddrIdx;
  private String loadAddrSido;
  private String loadAddrGu;
  private String loadAddrDong;
  private String loadAddrRo;
  private String loadAddrMainNum;
  private String loadAddrSubNum;
  private String loadAddrName;
}
