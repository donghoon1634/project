package bitc.fullstack503.java503_team3.service;
import java.util.List;
public interface BoardService3
{
  public void deleteUserlifeCommentMember (String memberId) throws Exception;
  
  public void deleteUserlifeFileMember (String memberId) throws Exception;
  
  public void deleteUserlifeMember (String memberId) throws Exception;
}
