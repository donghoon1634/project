package bitc.fullstack503.java503_team3.dto;
import lombok.Data;
@Data
public class MemberContentDTO
{
  private String memberContentId;
  private String memberContent;
}
