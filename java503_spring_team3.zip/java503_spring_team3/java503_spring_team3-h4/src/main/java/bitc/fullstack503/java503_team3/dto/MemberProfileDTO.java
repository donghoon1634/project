package bitc.fullstack503.java503_team3.dto;
import lombok.Data;
@Data
public class MemberProfileDTO
{
  private int memberProfileIdx;
  private String memberProfileHref;
  private String memberProfileMemberId;
}
