package bitc.fullstack503.java503_team3.dto;


import lombok.Data;

@Data
public class UserlifeCommentDTO {

    private int ulCommentIdx;
    private int ulCommentUlIdx;
    private String ulCommentNickname;
    private String ulCommentLocation;
    private String ulCommentcreatedate;
    private int ulCommentLike;
    private String ulCommentContents;
    private String ulComMemberId;
    private String memberProfile;
}
