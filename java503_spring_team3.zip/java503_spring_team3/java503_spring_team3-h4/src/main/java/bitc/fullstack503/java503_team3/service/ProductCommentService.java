package bitc.fullstack503.java503_team3.service;
import bitc.fullstack503.java503_team3.dto.ProductCommentDTO;

import java.util.List;
public interface ProductCommentService
{
  public void insertProductComment (ProductCommentDTO productCommentDTO) throws Exception;
  
  public List<ProductCommentDTO> getProductComment (int productCommentProductIdx) throws Exception;
  
  public void deleteProductComment (int productCommentProductIdx) throws Exception;
  
  public void deleteProductCommentMember (String productCommentMemberId) throws Exception;
}
