package bitc.fullstack503.java503_team3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Java503Team3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
