package bitc.fullstack503.blog.service;

import bitc.fullstack503.blog.dto.BlogCommentDTO;
import bitc.fullstack503.blog.dto.BlogDTO;
import bitc.fullstack503.blog.dto.BlogFileDTO;
import bitc.fullstack503.blog.dto.VisitDTO;
import bitc.fullstack503.blog.mapper.BlogMapper;
import bitc.fullstack503.blog.util.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;

import java.util.List;


@Service
public class BlogServiceImpl implements BlogService {

    @Autowired
    private BlogMapper blogMapper;
    @Autowired
    private FileUtil fileUtil;

    //    목록
    @Override
    public List<BlogDTO> selectBlogList()  {
        return blogMapper.selectBlogList();
    }

//    상세
    @Override
    public BlogDTO selectBlogDetail(int idx) {
        blogMapper.updateHitCnt(idx);
        BlogDTO blog = blogMapper.selectBlogDetail(idx);
        BlogFileDTO blogFile = new BlogFileDTO();
        blogFile = blogMapper.selectBlogFileInfo(idx,blogFile.getBlogIdx());
        if(blogFile!= null) {
            String imageUrl = "C:/Users/it/Desktop/스프링 개인 프로젝트_KDH/스프링 개인 프로젝트_KDH/스프링 개인 프로젝트_KDH/imgs" + blogFile.getStoredFileName();
            blog.setImageUrl(imageUrl);
        }
        return blog;
    }

    @Override
    public void insertBlog(BlogDTO blog) throws Exception {
        blogMapper.insertBlog(blog);
    }

//    등록



@Override
public void insertBlog(BlogDTO blog, MultipartHttpServletRequest request) throws Exception {
        blogMapper.insertBlog(blog);
        BlogFileDTO blogFile = new BlogFileDTO();
        List<BlogFileDTO> blogFileList = fileUtil.parseFileInfo(blogFile.getIdx(), blog.getIdx(), blog.getCreateId(),request);
        if(CollectionUtils.isEmpty(blogFileList) == false){
            blogMapper.insertBlogFileList(blogFileList);
        }
    }

//    수정
    @Override
    public void updateBlog(BlogDTO blog) {
        blogMapper.updateBlog(blog);
    }

//    삭제
    @Override
    public void deleteBlog(int idx) {
        blogMapper.deleteBlog(idx);
    }

    @Override
    public void visitBlog(VisitDTO visit) {
        blogMapper.visitBlog(visit);

    }


    @Override
    public List<VisitDTO> selectVisitList() {
        return blogMapper.selectVisitList();
    }

    @Override
    public List<BlogCommentDTO> getComment(int blogIdx) {
        return blogMapper.selectComment(blogIdx);
    }

    @Override
    public void addComment(BlogCommentDTO comment) {
        blogMapper.addComment(comment);
    }

    @Override
    public void updateComment(int idx) {
        blogMapper.updateComment(idx);
    }

    @Override
    public void deleteComment(int idx) {
        blogMapper.deleteComment(idx);
    }

    @Override
    public BlogFileDTO selectBlogFileInfo(int idx, int blogIdx) throws Exception {
        return blogMapper.selectBlogFileInfo(idx,blogIdx);
    }

}
