package bitc.fullstack503.blog.mapper;

import bitc.fullstack503.blog.dto.UserDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface UserMapper {

    int isUserInfo(@Param("userId") String userId, @Param("userPw") String userPw);

    UserDTO getUserInfo(@Param("userId") String userId);


    void insertUser(UserDTO user);
}
