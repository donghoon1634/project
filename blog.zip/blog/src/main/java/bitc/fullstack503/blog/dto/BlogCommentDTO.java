package bitc.fullstack503.blog.dto;

import lombok.Data;

@Data
public class BlogCommentDTO {
    private int idx;
    private int blogIdx;
    private String contents;
    private String createId;
    private String createDate;
}
