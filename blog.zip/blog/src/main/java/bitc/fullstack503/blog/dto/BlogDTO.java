package bitc.fullstack503.blog.dto;

import lombok.Data;

@Data
public class BlogDTO {
    private int idx;
    private String title;
    private String contents;
    private String createId;
    private String createDate;
    private String updateDate;
    private int hitCnt;
    private String imageUrl;
}
