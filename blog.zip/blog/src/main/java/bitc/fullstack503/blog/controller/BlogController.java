package bitc.fullstack503.blog.controller;

import bitc.fullstack503.blog.dto.BlogCommentDTO;
import bitc.fullstack503.blog.dto.BlogDTO;
import bitc.fullstack503.blog.dto.BlogFileDTO;
import bitc.fullstack503.blog.dto.VisitDTO;
import bitc.fullstack503.blog.service.BlogService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.apache.ibatis.annotations.Insert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Principal;
import java.util.List;

@Controller
public class BlogController {
    public static String UPLOADED_FOLDER = "C:\\Users\\it\\Desktop\\스프링 개인 프로젝트_KDH\\스프링 개인 프로젝트_KDH\\스프링 개인 프로젝트_KDH\\imgs";

    @Autowired
    private BlogService blogService;

    //         목록
    @RequestMapping(value = "/blog", method = RequestMethod.GET)
    public ModelAndView selectBlogList() throws Exception {
        ModelAndView mav = new ModelAndView("board/blogList");
        List<BlogDTO> blogList = blogService.selectBlogList();
        mav.addObject("blogList", blogList);
        return mav;
    }


    //        상세
    @RequestMapping(value = "/blog/{idx}", method = RequestMethod.GET)
    public ModelAndView selectBlogDetail(@PathVariable("idx") int idx, HttpServletRequest request) throws Exception {
        HttpSession session = request.getSession();

        ModelAndView mav = new ModelAndView("board/blogDetail");
        if(session.getAttribute("userName") == null) {
            mav.setViewName("redirect:/blog/login/login.do");
        }
        else{
            mav.setViewName("/board/blogDetail");
        }

        BlogDTO blog = blogService.selectBlogDetail(idx);
        String username = (String) session.getAttribute("userName");
        mav.addObject("username", username);
        mav.addObject("blog", blog);

        BlogFileDTO blogFile = new BlogFileDTO();
        blogFile = blogService.selectBlogFileInfo(idx, blogFile.getBlogIdx());
        mav.addObject("blogFile", blogFile);

        List<BlogCommentDTO> commentList = blogService.getComment(idx);
        mav.addObject("commentList", commentList);

        return mav;
    }

    @PostMapping( "/blog/{idx}/comment")
    public ModelAndView addComment(@PathVariable("idx") int idx, @ModelAttribute BlogCommentDTO comment ,HttpServletRequest request)throws Exception{
        ModelAndView mav = new ModelAndView("board/blogDetail");
        HttpSession session = request.getSession();
        if (comment.getContents() == null || comment.getContents().trim().isEmpty()) {
            comment.setContents("");
        }

        if (session.getAttribute("userName") != null) {
            mav.setViewName("redirect:/blog/" + idx);
        }
        else {
            mav.setViewName("redirect:/blog/login/login.do");
            return mav;
        }
        BlogDTO blog = blogService.selectBlogDetail(idx);
        if (blog == null) {
            mav.addObject("errorMessage", "블로그를 찾을 수 없습니다.");
            return mav;
        }
        comment.setBlogIdx(idx);
        blogService.addComment(comment);

        mav.addObject("comment", comment);
        mav.addObject("blog",blog);
        return mav;
    }




    //    글 작성
    @GetMapping("/blog/write")
    public String insertBlog(HttpServletRequest request) throws Exception {
        HttpSession session = request.getSession();

        if (session.getAttribute("userName") == null) {
            return "redirect:/blog/login/login.do";
        }
        return "board/blogWrite";
    }

    //    등록 처리
    @PostMapping("/blog/write")
    public String insertBlog(@ModelAttribute BlogDTO blog, MultipartHttpServletRequest request) throws Exception {
        blogService.insertBlog(blog, request);
        return "redirect:/blog";
    }

    //    수정
    @PutMapping("/blog/{idx}")
    public String updateBlog(BlogDTO blog) throws Exception {
        blogService.updateBlog(blog);
        return "redirect:/blog";
    }

    //    삭제
    @DeleteMapping("/blog/{idx}")
    public String deleteBlog(@PathVariable("idx") int idx) throws Exception {
        blogService.deleteBlog(idx);
        return "redirect:/blog";
    }

    //    이미지 업로드


//    방명록 등록
    @GetMapping("/blog/visit")
    public String visitBlog(HttpServletRequest request) throws Exception {
        HttpSession session = request.getSession();

        if (session.getAttribute("userName") == null) {
            return "redirect:/blog/login/login.do";
        }
        return "board/visit";
    }

//    처리
    @PostMapping("/blog/visit")
    public String visitBlog(VisitDTO visit) throws Exception {
        blogService.visitBlog(visit);
        return "redirect:/blog/visit";
    }

//    조회
    @RequestMapping(value = "/blog/visit/visit", method = RequestMethod.GET)
    public ModelAndView selectVisitList() throws Exception {
        ModelAndView mav = new ModelAndView("board/visitList");
        List<VisitDTO> visitList = blogService.selectVisitList();
        mav.addObject("visitList", visitList);
        return mav;
    }

    //    수정
    @PutMapping("/blog/{idx}/comment")
    public String updateComment(@PathVariable("idx") int idx) throws Exception {
        blogService.updateComment(idx);
        return "redirect:/blog/" + idx;
    }

    //    삭제
    @DeleteMapping("/blog/{idx}/comment")
    public String deleteComment(@PathVariable("idx") int idx) throws Exception {
        blogService.deleteComment(idx);
        return "redirect:/blog/" + idx;
    }
}