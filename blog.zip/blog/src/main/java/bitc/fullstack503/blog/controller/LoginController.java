package bitc.fullstack503.blog.controller;

import bitc.fullstack503.blog.dto.UserDTO;
import bitc.fullstack503.blog.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.net.URLEncoder;

@Controller
@RequestMapping("/blog/login")
public class LoginController {
    @Autowired
    private UserService userService;

    @RequestMapping("/login.do")
    public String login() {
        return "login/login";
    }



    @RequestMapping("/loginProcess.do")
    public String loginProcess( String userId,  String userPw, HttpServletRequest request) throws Exception {
        if(userId == null || userId.isEmpty() || userPw == null || userPw.isEmpty()) {
            return "redirect:/blog/login/login.do?errMsg=" + URLEncoder.encode("아이디 또는 비밀번호를 입력해주세요.", "UTF-8");
        }

        boolean result = userService.isUserInfo(userId, userPw);
        if (result) {
            UserDTO user = userService.getUserInfo(userId);

            HttpSession session = request.getSession();
            session.setAttribute("userId", user.getUserId());
            session.setAttribute("userPw", user.getUserPw());
            session.setAttribute("userName", user.getUserName());


            session.setMaxInactiveInterval(60*5);
            return "redirect:/blog";
        } else {
            return "redirect:/blog/login/login.do?errMsg=" + URLEncoder.encode("로그인 정보 다름", "UTF-8");
        }
    }
    @RequestMapping("/signup.do")
    public String signup() {
        return "login/signup";
    }

    @PostMapping("/signupProcess.do")
    public String signupProcess ( @RequestParam("userName") String userName,@RequestParam("userId") String userId, @RequestParam("userPw") String userPw,  @RequestParam("userEmail") String userEmail) throws Exception {
        boolean isUserExist = userService.isUserExist(userId);
        if (isUserExist) {
            return "redirect:/blog/login/login.do?errMsg= " + URLEncoder.encode("이미 존재함","UTF-8");
        }
        else{
            UserDTO user = new UserDTO();
            user.setUserName(userName);
            user.setUserId(userId);
            user.setUserPw(userPw);
            user.setUserEmail(userEmail);

            userService.addUser(user);
            return "redirect:/blog";
        }
    }

    @RequestMapping("/logout.do")
    public String logout(HttpServletRequest request) throws Exception {
        HttpSession session = request.getSession();
     session.removeAttribute("userId");
     session.removeAttribute("userPw");
     session.removeAttribute("userEmail");
     session.invalidate();

        return "redirect:/blog/login/login.do";
    }

}
