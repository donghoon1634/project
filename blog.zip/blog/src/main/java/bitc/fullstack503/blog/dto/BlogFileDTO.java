package bitc.fullstack503.blog.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Data
public class BlogFileDTO {
    private int idx;
    private int blogIdx;
    private String originalFileName;
    private String storedFileName;
    private long fileSize;
    private String createId;
    private String createDate;
    private String updateId;
    private String updateDate;
}
