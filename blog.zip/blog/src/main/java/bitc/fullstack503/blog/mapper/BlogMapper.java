package bitc.fullstack503.blog.mapper;

import bitc.fullstack503.blog.dto.BlogCommentDTO;
import bitc.fullstack503.blog.dto.BlogDTO;
import bitc.fullstack503.blog.dto.BlogFileDTO;
import bitc.fullstack503.blog.dto.VisitDTO;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import java.io.IOException;
import java.util.List;

@Mapper
public interface BlogMapper {

//    목록
    List<BlogDTO> selectBlogList() ;

    BlogDTO selectBlogDetail(int idx);

    void insertBlog(BlogDTO blog) throws Exception;

    void updateBlog(BlogDTO blog);

    void deleteBlog(int idx);


    void visitBlog(VisitDTO visit);


    List<VisitDTO> selectVisitList();

    List<BlogCommentDTO> selectComment(int blogIdx);
    void addComment(BlogCommentDTO comment);

    void updateHitCnt(int idx);

    void updateComment(int idx);

    void deleteComment(int idx);

    BlogFileDTO selectBlogFileInfo(int idx, int blogIdx);

    void insertBlogFileList(List<BlogFileDTO> blogFileList) throws Exception;
}
