package bitc.fullstack503.blog.service;

import bitc.fullstack503.blog.dto.BlogCommentDTO;
import bitc.fullstack503.blog.dto.BlogDTO;
import bitc.fullstack503.blog.dto.BlogFileDTO;
import bitc.fullstack503.blog.dto.VisitDTO;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;

import java.util.List;

public interface BlogService {
    List<BlogDTO> selectBlogList() ;

    BlogDTO selectBlogDetail(int idx);


    //    등록
    void insertBlog(BlogDTO blog) throws Exception;
    void insertBlog(BlogDTO blog, MultipartHttpServletRequest request) throws Exception;

    void updateBlog(BlogDTO blog);

    void deleteBlog(int idx);

    void visitBlog(VisitDTO visit);

    List<VisitDTO> selectVisitList();

    List<BlogCommentDTO> getComment(int idx);
    void addComment(BlogCommentDTO comment);

    void updateComment(int idx);

    void deleteComment(int idx);

    public BlogFileDTO selectBlogFileInfo(int idx, int blogIdx) throws Exception;

}
