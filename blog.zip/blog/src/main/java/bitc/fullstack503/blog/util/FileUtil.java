package bitc.fullstack503.blog.util;

import bitc.fullstack503.blog.dto.BlogFileDTO;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import java.io.File;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Component
public class FileUtil {
    public List<BlogFileDTO> parseFileInfo(int idx , int blogIdx, String createId, MultipartHttpServletRequest request) throws Exception {
        if(ObjectUtils.isEmpty(request)) {
            return null;
        }
        List<BlogFileDTO> fileList = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        ZonedDateTime current = ZonedDateTime.now();

        String path = "C:/Users/it/Desktop/스프링 개인 프로젝트_KDH/스프링 개인 프로젝트_KDH/스프링 개인 프로젝트_KDH/imgs" + current.format(formatter);

        File file = new File(path);

        if(file.exists() == false) {
            file.mkdirs();
        }
        Iterator<String> iterator = request.getFileNames();

        String newFileName;
        String originalFileExt;
        String contentType;

        while(iterator.hasNext()) {

            String name = iterator.next();
            List<MultipartFile> multipartFileList = request.getFiles(name);

            for(MultipartFile uploadFile : multipartFileList) {
                contentType = uploadFile.getContentType();

                if(ObjectUtils.isEmpty(contentType)){
                    break;
                }
                else{
                    if(contentType.contains("image/jpeg")) {
                        originalFileExt = ".jpg";
                    }
                    else if(contentType.contains("image/png")) {
                        originalFileExt = ".png";
                    }
                    else if(contentType.contains("video/gif")) {
                        originalFileExt = ".gif";
                    }
                    else{
                        break;
                    }
                }
                newFileName = System.nanoTime() + originalFileExt;

                BlogFileDTO blogFileDTO = new BlogFileDTO();
                blogFileDTO.setBlogIdx(blogIdx);
                blogFileDTO.setFileSize(uploadFile.getSize());
                blogFileDTO.setOriginalFileName(uploadFile.getOriginalFilename());
                blogFileDTO.setStoredFileName(path +"/"+ newFileName);
                blogFileDTO.setCreateId(createId);
                fileList.add(blogFileDTO);

                file = new File(path +"/"+ newFileName);
                uploadFile.transferTo(file);
            }
        }
        return fileList;
    }
}
