package bitc.fullstack503.blog.dto;

import lombok.Data;

@Data
public class UserDTO {
    private String userId;
    private String userPw;
    private String userName;
    private String userEmail;
    private String createDate;
}
