package bitc.fullstack503.blog.dto;

import lombok.Data;

@Data
public class VisitDTO {
private int idx;
private String createId;
private String contents;
}
