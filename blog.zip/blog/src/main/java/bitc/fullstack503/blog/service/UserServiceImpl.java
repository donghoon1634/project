package bitc.fullstack503.blog.service;

import bitc.fullstack503.blog.dto.UserDTO;
import bitc.fullstack503.blog.mapper.UserMapper;
import jakarta.websocket.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import java.util.UUID;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Override
    public boolean isUserInfo(String userId, String userPw) {
        UserDTO user = userMapper.getUserInfo(userId);
        if(user != null && user.getUserPw() != null) {
            return user.getUserPw().equals(userPw);
        }

        return false;
    }

    @Override
    public UserDTO getUserInfo(String userId) {
        return userMapper.getUserInfo(userId);
    }

    @Override
    public boolean isUserExist(String userId) {
        UserDTO user = userMapper.getUserInfo(userId);
        return user != null;
    }

    @Override
    public void addUser(UserDTO user) {
        userMapper.insertUser(user);
    }



//
//
//    @Override
//    public boolean isUserInfo(String userId, String userPw) {
//
//        int result = userMapper.isUserInfo(userId,userPw);
//
//        if(result == 1){
//            return true;
//        }
//        else{
//            return false;
//        }
//    }
//
//    @Override
//    public UserDTO getUserInfo(String userId) {
//
//        return userMapper.getUserInfo(userId);
//    }

}