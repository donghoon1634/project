package bitc.fullstack503.blog.service;

import bitc.fullstack503.blog.dto.UserDTO;

public interface UserService {

    boolean isUserInfo(String userId, String userPw);

    UserDTO getUserInfo(String userId);

    boolean isUserExist(String userId);

    void addUser(UserDTO user);
}
