//package bitc.fullstack503.blog.controller;
//
//import bitc.fullstack503.blog.dto.BlogDTO;
//import bitc.fullstack503.blog.service.BlogService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.*;
//import org.springframework.web.servlet.ModelAndView;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("/blog/api")
//public class BlogApiController {
//
//    @Autowired
//    private BlogService blogService;
//
//    //         목록
//    @RequestMapping(value = "/blog",method = RequestMethod.GET)
//    public Object selectBlogList() throws Exception {
//        List<BlogDTO> blogList = blogService.selectBlogList();
//        return blogList;
//    }
//
//
//    //        상세
//    @GetMapping("/blog/{idx}")
//    public Object selectBoard(@PathVariable("idx") int idx) throws Exception {
//        BlogDTO blog = blogService.selectBlogDetail(idx);
//        return blog;
//    }
//
////    등록
//    @PostMapping("/blog/write")
//    public void insertBlog(@RequestBody BlogDTO blog) throws Exception {
//        blogService.insertBlog(blog);
//    }
//
//    @PutMapping("/blog/{idx}")
//    public void updateBlog(@PathVariable("idx") int idx, @RequestBody BlogDTO blog) {
//        blog.setIdx(idx);
//        blogService.updateBlog(blog);
//    }
//
//    @DeleteMapping("/blog/{idx}")
//    public void deleteBlog(@PathVariable("idx") int idx) {
//        blogService.deleteBlog(idx);
//    }
//}
